package com.example.mycryptoexample.Crypto;

import android.util.Base64;

public class ActivityBase {

    public static String encode(String s, String xorKey) {
        String result = null;
        try {
            result = base64Encode(xorWithKey(s.getBytes(), xorKey.getBytes()));
        } catch (XorKeyException e) {
            e.printStackTrace();
        }

        return result;
    }

    public static String decode(String s, String xorKey) {
        String result = null;
        try {
            result = new String(xorWithKey(base64Decode(s), xorKey.getBytes()));
        } catch (XorKeyException e) {
            e.printStackTrace();
        }

        return result;
    }

    private static byte[] xorWithKey(byte[] a, byte[] key) throws XorKeyException {

        if(key.length == 0 ){
            throw new XorKeyException("xorKey is Empty");
        }

        byte[] out = new byte[a.length];
        for (int i = 0; i < a.length; i++) {
            out[i] = (byte) (a[i] ^ key[i%key.length]);
        }
        return out;
    }

    private static byte[] base64Decode(String s) {
        return  Base64.decode(s, Base64.NO_WRAP);
    }

    private static String base64Encode(byte[] bytes) {

        String encoded = Base64.encodeToString(bytes, Base64.NO_WRAP).replaceAll("\\s", "");

        return encoded;
    }
}