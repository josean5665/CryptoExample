package com.example.mycryptoexample.Commons;

import android.util.Log;

import com.example.mycryptoexample.Crypto.ActivityBase;
import com.example.mycryptoexample.classes.PKEValues;


public class Constants {

    private static final PKEValues values = new PKEValues();

    private static String getXorKey() {

        String returnValue = "";
        try {
            returnValue = values.getPKE();
        } catch (UnsatisfiedLinkError e) {
            Log.e("TAG", "Error loading value " + e.getLocalizedMessage());
        }
        return returnValue;
    }


    public static String getURL(){
        return ActivityBase.decode("MiwuHFlBfQs2XCkAPB01Fgw=", getXorKey());
    }



}
