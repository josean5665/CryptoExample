package com.example.mycryptoexample.classes;

import android.util.Log;

public class PKEValues {

    private static final String TAG = "Values" ;

    static{

        try {
            System.loadLibrary("PKE");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Error loading library "+e.getLocalizedMessage());
        }
    }

    public native String getPKE();
    public native String getBaseURL();

}
