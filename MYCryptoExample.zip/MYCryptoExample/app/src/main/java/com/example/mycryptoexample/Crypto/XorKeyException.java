package com.example.mycryptoexample.Crypto;

public class XorKeyException extends Exception{
    public XorKeyException(){super();}
    public XorKeyException(String message){super(message);}
    public XorKeyException(String message,Throwable cause){super(message,cause);}
    public XorKeyException(Throwable cause){super(cause);}
}
