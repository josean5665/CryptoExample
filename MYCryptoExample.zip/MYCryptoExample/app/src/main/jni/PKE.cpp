//
// Created by jjimenez on 3/11/2020.
//

#include <string>
#include "com_example_mycryptoexample_classes_PKEValues.h"

JNIEXPORT jstring JNICALL Java_com_example_mycryptoexample_classes_PKEValues_getBaseURL
        (JNIEnv * env, jobject)
{
    return env->NewStringUTF("MiwuHFlBfQs2XCkAPB01Fgw=");
}

JNIEXPORT jstring JNICALL Java_com_example_mycryptoexample_classes_PKEValues_getPKE
    (JNIEnv * env, jobject)
{
    std::string xorKey1 = "yaXR5Y2hhaW5lbm";
    std::string xorKey2 = "ZXZlcnRlY3NlY3V";
    std::string xorKey3 = "NvZGVrZXk=";
    std::string mixedXor = xorKey2+xorKey1+xorKey3;
    return env->NewStringUTF(mixedXor.c_str());
}






