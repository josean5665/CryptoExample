package com.example.mycryptoexample.Crypto;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.SmallTest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class ActivityBaseTest {

    private static final String xorKey = "ZXZlcnRlY3NlY3VyaXR5Y2hhaW5lbmNvZGVrZXk=";

    @Before
    public void setUp() throws Exception {

        //you other setup here
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testEncodeDecode() throws Exception {

        String value = "http://google.com";
        String encoded  = ActivityBase.encode(value,xorKey);
        String decoded = ActivityBase.decode(encoded,xorKey);
        Log.d("Encoded value",encoded);
        Log.d("Decoded value",decoded);
        assertEquals(value,decoded);
    }

    @Test
    public void testEncode() throws Exception {

        String value = "";
        String encoded  = ActivityBase.encode(value,xorKey);
        Log.d("Encoded value",encoded);

        assertNotNull(encoded);
    }

    @Test
    public void testDecode() throws Exception {

        String value = "";
        String decoded  = ActivityBase.decode(value,xorKey);

        Log.d("ActivityBase",decoded);

        assertNotNull(decoded);

    }
}
